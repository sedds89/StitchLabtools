# What this proves — and what it does not

## Demonstrated by this run

- A frontier model operated inside a Frankenstein workspace.
- It created and modified a real Android project.
- It attempted real builds rather than only emitting source text.
- It encountered build failures and changed strategy.
- It produced a signed Android APK on the device-side toolchain.
- The resulting APK was installed and launched during the run.

## Not claimed by this package

- That every originally requested FieldForge feature was present in the final fallback APK.
- That the Kotlin/Compose/Room route completed successfully in this run.
- That a local llama model was provisioned for this run.
- That frontier-teacher -> LoRA -> improved offline agent was certified end-to-end.

The goal of this public artifact is narrow: provide credible evidence of the autonomous software-build/recovery loop while withholding the proprietary implementation of Frankenstein itself.
