# FieldForge — Frankenstein public proof run

This archive is a **sanitized public proof artifact** from a Frankenstein Ultra agent run. It is intended to demonstrate system capability and authorship without publishing Frankenstein/Victor production internals, private runtime state, signing material, or proprietary orchestration details.

## What the run demonstrated

A frontier model operating through Frankenstein worked inside a real Android workspace, attempted the intended Kotlin/Compose build route, encountered environment/build failures, changed strategy, and ultimately produced a signed Android APK through a lower-level on-device build path.

The successful fallback pipeline was:

`aapt2 compile -> aapt2 link -> javac -> d8 -> zipalign -> apksigner`

The resulting APK was then installed and launched on the Android device during the run.

## Included

- Generated Kotlin/Compose project source
- Generated lower-level Java fallback source
- Final signed `FieldForge.apk`
- Sanitized build/recovery evidence
- APK SHA-256 checksum

## Intentionally omitted

- Frankenstein/Victor production source
- Raw `.aide` agent state and working-context files
- Internal tool-call signatures and orchestration state
- Device-private runtime paths
- Signing keystores/private keys
- Local machine properties
- Private authentication/secrets material
- Stale certification artifacts that were superseded by the later successful build

## Important scope note

This package proves the **build/recovery/install/launch** portion of the FieldForge run. It does not claim that the separate frontier-model -> LoRA -> improved offline-agent loop was certified by this run.

See `evidence/build-result.json` and `evidence/recovery.md` for the curated evidence summary.
