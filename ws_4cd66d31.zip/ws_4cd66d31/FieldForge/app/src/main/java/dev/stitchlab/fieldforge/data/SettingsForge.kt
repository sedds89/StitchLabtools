package dev.stitchlab.fieldforge.data

import android.content.Context
import dev.stitchlab.fieldforge.domain.ForgeResult
import dev.stitchlab.fieldforge.domain.model.ThemePreference
import dev.stitchlab.fieldforge.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsForge(context: Context) : SettingsRepository {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val themeFlow = MutableStateFlow(readTheme())

    override fun observeTheme(): Flow<ThemePreference> = themeFlow.asStateFlow()

    override suspend fun setTheme(preference: ThemePreference): ForgeResult<Unit> = try {
        prefs.edit().putString(KEY_THEME, preference.name).apply()
        themeFlow.value = preference
        ForgeResult.Ok(Unit)
    } catch (t: Throwable) {
        ForgeResult.Err(t.message ?: "Failed to save theme", t)
    }

    private fun readTheme(): ThemePreference {
        val raw = prefs.getString(KEY_THEME, ThemePreference.SYSTEM.name) ?: ThemePreference.SYSTEM.name
        return runCatching { ThemePreference.valueOf(raw) }.getOrDefault(ThemePreference.SYSTEM)
    }

    private companion object {
        const val PREFS = "fieldforge_settings"
        const val KEY_THEME = "theme_preference"
    }
}
