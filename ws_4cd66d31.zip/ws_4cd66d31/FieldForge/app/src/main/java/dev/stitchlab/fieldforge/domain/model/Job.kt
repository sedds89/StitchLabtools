package dev.stitchlab.fieldforge.domain.model

data class Job(
    val id: Long = 0L,
    val customerName: String,
    val phone: String,
    val address: String,
    val description: String,
    val priority: JobPriority,
    val status: JobStatus,
    val notes: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val scheduledForEpochMs: Long,
)

enum class JobPriority { LOW, NORMAL, HIGH, URGENT }

enum class JobStatus { OPEN, COMPLETED }

data class JobNote(
    val id: Long = 0L,
    val jobId: Long,
    val body: String,
    val createdAtEpochMs: Long,
)

enum class ThemePreference { SYSTEM, LIGHT, DARK }
