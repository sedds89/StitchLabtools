package dev.stitchlab.fieldforge

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import dev.stitchlab.fieldforge.domain.model.ThemePreference
import dev.stitchlab.fieldforge.ui.FieldForgeNav
import dev.stitchlab.fieldforge.ui.theme.FieldForgeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as FieldForgeApp
        setContent {
            val theme by app.container.settingsRepository.observeTheme().collectAsState(initial = ThemePreference.SYSTEM)
            FieldForgeTheme(preference = theme) {
                FieldForgeNav(container = app.container)
            }
        }
    }
}
