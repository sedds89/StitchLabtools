package dev.stitchlab.fieldforge.feature.jobs

import dev.stitchlab.fieldforge.domain.model.Job
import dev.stitchlab.fieldforge.domain.model.JobNote

data class JobDetailUiState(
    val job: Job? = null,
    val notes: List<JobNote> = emptyList(),
    val noteDraft: String = "",
    val loading: Boolean = true,
    val showDeleteConfirm: Boolean = false,
    val deleted: Boolean = false,
    val errorMessage: String? = null,
)
