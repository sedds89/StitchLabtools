package dev.stitchlab.fieldforge.data

import dev.stitchlab.fieldforge.data.local.JobDao
import dev.stitchlab.fieldforge.data.local.JobEntity
import dev.stitchlab.fieldforge.data.local.JobNoteDao
import dev.stitchlab.fieldforge.data.local.JobNoteEntity
import dev.stitchlab.fieldforge.domain.ForgeResult
import dev.stitchlab.fieldforge.domain.model.Job
import dev.stitchlab.fieldforge.domain.model.JobNote
import dev.stitchlab.fieldforge.domain.model.JobPriority
import dev.stitchlab.fieldforge.domain.model.JobStatus
import dev.stitchlab.fieldforge.domain.repository.JobRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class JobForge(
    private val jobDao: JobDao,
    private val noteDao: JobNoteDao
) : JobRepository {

    override fun observeJobs(): Flow<List<Job>> =
        jobDao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeJob(id: Long): Flow<Job?> =
        jobDao.observeById(id).map { it?.toDomain() }

    override fun observeNotes(jobId: Long): Flow<List<JobNote>> =
        noteDao.observeForJob(jobId).map { list -> list.map { it.toDomain() } }

    override suspend fun getJob(id: Long): ForgeResult<Job> = try {
        val entity = jobDao.getById(id)
        if (entity == null) ForgeResult.Err("Job not found")
        else ForgeResult.Ok(entity.toDomain())
    } catch (t: Throwable) {
        ForgeResult.Err(t.message ?: "Failed to load job", t)
    }

    override suspend fun upsert(job: Job): ForgeResult<Long> = try {
        val id = jobDao.insert(job.toEntity())
        ForgeResult.Ok(id)
    } catch (t: Throwable) {
        ForgeResult.Err(t.message ?: "Failed to save job", t)
    }

    override suspend fun delete(id: Long): ForgeResult<Unit> = try {
        jobDao.deleteById(id)
        ForgeResult.Ok(Unit)
    } catch (t: Throwable) {
        ForgeResult.Err(t.message ?: "Failed to delete job", t)
    }

    override suspend fun setStatus(id: Long, status: JobStatus): ForgeResult<Unit> = try {
        jobDao.updateStatus(id, status.name, System.currentTimeMillis())
        ForgeResult.Ok(Unit)
    } catch (t: Throwable) {
        ForgeResult.Err(t.message ?: "Failed to update status", t)
    }

    override suspend fun addNote(jobId: Long, body: String): ForgeResult<Unit> = try {
        noteDao.insert(
            JobNoteEntity(
                id = 0L,
                jobId = jobId,
                body = body.trim(),
                createdAtEpochMs = System.currentTimeMillis()
            )
        )
        ForgeResult.Ok(Unit)
    } catch (t: Throwable) {
        ForgeResult.Err(t.message ?: "Failed to add note", t)
    }
}

private fun JobEntity.toDomain(): Job = Job(
    id = id,
    customerName = customerName,
    phone = phone,
    address = address,
    description = description,
    priority = runCatching { JobPriority.valueOf(priority) }.getOrDefault(JobPriority.NORMAL),
    status = runCatching { JobStatus.valueOf(status) }.getOrDefault(JobStatus.OPEN),
    notes = notes,
    createdAtEpochMs = createdAtEpochMs,
    updatedAtEpochMs = updatedAtEpochMs,
    scheduledForEpochMs = scheduledForEpochMs
)

private fun Job.toEntity(): JobEntity = JobEntity(
    id = id,
    customerName = customerName,
    phone = phone,
    address = address,
    description = description,
    priority = priority.name,
    status = status.name,
    notes = notes,
    createdAtEpochMs = createdAtEpochMs,
    updatedAtEpochMs = updatedAtEpochMs,
    scheduledForEpochMs = scheduledForEpochMs
)

private fun JobNoteEntity.toDomain(): JobNote = JobNote(
    id = id,
    jobId = jobId,
    body = body,
    createdAtEpochMs = createdAtEpochMs
)
