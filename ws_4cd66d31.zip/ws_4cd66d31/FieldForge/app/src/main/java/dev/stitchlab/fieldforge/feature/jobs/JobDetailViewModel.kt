package dev.stitchlab.fieldforge.feature.jobs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dev.stitchlab.fieldforge.domain.ForgeResult
import dev.stitchlab.fieldforge.domain.model.JobStatus
import dev.stitchlab.fieldforge.domain.repository.JobRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JobDetailViewModel(
    private val jobId: Long,
    private val jobs: JobRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(JobDetailUiState())
    val state: StateFlow<JobDetailUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(jobs.observeJob(jobId), jobs.observeNotes(jobId)) { job, notes ->
                job to notes
            }.collect { (job, notes) ->
                _state.update {
                    it.copy(job = job, notes = notes, loading = false)
                }
            }
        }
    }

    fun onNoteDraft(value: String) {
        _state.update { it.copy(noteDraft = value) }
    }

    fun addNote() {
        val text = _state.value.noteDraft
        viewModelScope.launch {
            when (val result = jobs.addNote(jobId, text)) {
                is ForgeResult.Ok -> _state.update { it.copy(noteDraft = "", errorMessage = null) }
                is ForgeResult.Err -> _state.update { it.copy(errorMessage = result.message) }
            }
        }
    }

    fun markCompleted() {
        viewModelScope.launch {
            when (val result = jobs.setStatus(jobId, JobStatus.COMPLETED)) {
                is ForgeResult.Ok -> _state.update { it.copy(errorMessage = null) }
                is ForgeResult.Err -> _state.update { it.copy(errorMessage = result.message) }
            }
        }
    }

    fun reopen() {
        viewModelScope.launch {
            when (val result = jobs.setStatus(jobId, JobStatus.OPEN)) {
                is ForgeResult.Ok -> _state.update { it.copy(errorMessage = null) }
                is ForgeResult.Err -> _state.update { it.copy(errorMessage = result.message) }
            }
        }
    }

    fun requestDelete() {
        _state.update { it.copy(showDeleteConfirm = true) }
    }

    fun cancelDelete() {
        _state.update { it.copy(showDeleteConfirm = false) }
    }

    fun confirmDelete() {
        viewModelScope.launch {
            when (val result = jobs.delete(jobId)) {
                is ForgeResult.Ok -> _state.update {
                    it.copy(deleted = true, showDeleteConfirm = false, errorMessage = null)
                }
                is ForgeResult.Err -> _state.update {
                    it.copy(showDeleteConfirm = false, errorMessage = result.message)
                }
            }
        }
    }

    companion object {
        fun factory(jobId: Long, jobs: JobRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return JobDetailViewModel(jobId, jobs) as T
                }
            }
    }
}
