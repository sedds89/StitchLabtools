package dev.stitchlab.fieldforge.domain.repository

import dev.stitchlab.fieldforge.domain.ForgeResult

interface ExportRepository {
    suspend fun exportJobsJson(): ForgeResult<String>
}
