package dev.stitchlab.fieldforge.feature.jobs

import dev.stitchlab.fieldforge.domain.model.Job
import dev.stitchlab.fieldforge.domain.model.JobFilter

data class JobsUiState(
    val jobs: List<Job> = emptyList(),
    val query: String = "",
    val filter: JobFilter = JobFilter.ALL,
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
)
