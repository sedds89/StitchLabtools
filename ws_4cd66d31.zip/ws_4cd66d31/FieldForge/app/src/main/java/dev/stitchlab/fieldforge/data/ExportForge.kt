package dev.stitchlab.fieldforge.data

import android.content.Context
import android.os.Environment
import dev.stitchlab.fieldforge.data.local.JobDao
import dev.stitchlab.fieldforge.domain.ForgeResult
import dev.stitchlab.fieldforge.domain.repository.ExportRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExportForge(
    private val context: Context,
    private val jobDao: JobDao
) : ExportRepository {
    override suspend fun exportJobsJson(): ForgeResult<String> = try {
        val jobs = jobDao.getAll()
        val array = JSONArray()
        jobs.forEach { job ->
            array.put(
                JSONObject().apply {
                    put("id", job.id)
                    put("customerName", job.customerName)
                    put("phone", job.phone)
                    put("address", job.address)
                    put("description", job.description)
                    put("priority", job.priority)
                    put("status", job.status)
                    put("notes", job.notes)
                    put("createdAt", job.createdAtEpochMs)
                    put("updatedAt", job.updatedAtEpochMs)
                    put("scheduledFor", job.scheduledForEpochMs)
                }
            )
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "fieldforge_jobs_$stamp.json"
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, fileName)
        file.writeText(array.toString(2))
        ForgeResult.Ok(file.absolutePath)
    } catch (t: Throwable) {
        ForgeResult.Err(t.message ?: "Export failed", t)
    }
}
