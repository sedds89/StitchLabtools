package dev.stitchlab.fieldforge.di

import android.content.Context
import dev.stitchlab.fieldforge.data.ExportForge
import dev.stitchlab.fieldforge.data.JobForge
import dev.stitchlab.fieldforge.data.SettingsForge
import dev.stitchlab.fieldforge.data.local.FieldForgeDatabase
import dev.stitchlab.fieldforge.domain.repository.ExportRepository
import dev.stitchlab.fieldforge.domain.repository.JobRepository
import dev.stitchlab.fieldforge.domain.repository.SettingsRepository

class AppContainer(context: Context) {
    private val db = FieldForgeDatabase.get(context)
    val jobRepository: JobRepository = JobForge(db.jobDao(), db.jobNoteDao())
    val settingsRepository: SettingsRepository = SettingsForge(context)
    val exportRepository: ExportRepository = ExportForge(context, db.jobDao())
}
