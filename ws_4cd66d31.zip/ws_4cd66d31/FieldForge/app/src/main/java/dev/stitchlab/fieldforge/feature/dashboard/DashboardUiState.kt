package dev.stitchlab.fieldforge.feature.dashboard

import dev.stitchlab.fieldforge.domain.model.Job

data class DashboardUiState(
    val openCount: Int = 0,
    val completedCount: Int = 0,
    val todaysJobs: List<Job> = emptyList(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
)
