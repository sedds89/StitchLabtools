package dev.stitchlab.fieldforge.data.local

import dev.stitchlab.fieldforge.domain.model.Job
import dev.stitchlab.fieldforge.domain.model.JobPriority
import dev.stitchlab.fieldforge.domain.model.JobStatus

data class JobEntity(
    val id: Long = 0L,
    val customerName: String,
    val phone: String,
    val address: String,
    val description: String,
    val priority: String,
    val status: String,
    val notes: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val scheduledForEpochMs: Long,
) {
    fun toDomain(): Job = Job(
        id = id,
        customerName = customerName,
        phone = phone,
        address = address,
        description = description,
        priority = runCatching { JobPriority.valueOf(priority) }.getOrDefault(JobPriority.NORMAL),
        status = runCatching { JobStatus.valueOf(status) }.getOrDefault(JobStatus.OPEN),
        notes = notes,
        createdAtEpochMs = createdAtEpochMs,
        updatedAtEpochMs = updatedAtEpochMs,
        scheduledForEpochMs = scheduledForEpochMs,
    )

    companion object {
        fun fromDomain(job: Job): JobEntity = JobEntity(
            id = job.id,
            customerName = job.customerName,
            phone = job.phone,
            address = job.address,
            description = job.description,
            priority = job.priority.name,
            status = job.status.name,
            notes = job.notes,
            createdAtEpochMs = job.createdAtEpochMs,
            updatedAtEpochMs = job.updatedAtEpochMs,
            scheduledForEpochMs = job.scheduledForEpochMs,
        )
    }
}
