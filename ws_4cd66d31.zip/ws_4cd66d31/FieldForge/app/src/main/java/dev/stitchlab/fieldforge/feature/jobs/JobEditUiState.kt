package dev.stitchlab.fieldforge.feature.jobs

import dev.stitchlab.fieldforge.domain.model.JobPriority
import dev.stitchlab.fieldforge.domain.model.JobStatus

data class JobEditUiState(
    val jobId: Long? = null,
    val customerName: String = "",
    val phone: String = "",
    val address: String = "",
    val description: String = "",
    val priority: JobPriority = JobPriority.NORMAL,
    val status: JobStatus = JobStatus.OPEN,
    val notes: String = "",
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val saved: Boolean = false,
    val errorMessage: String? = null,
    val isEdit: Boolean = false,
)
