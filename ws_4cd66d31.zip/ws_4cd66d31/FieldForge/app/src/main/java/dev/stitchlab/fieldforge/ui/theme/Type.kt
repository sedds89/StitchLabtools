package dev.stitchlab.fieldforge.ui.theme

import androidx.compose.material3.Typography

val FieldForgeTypography = Typography()
