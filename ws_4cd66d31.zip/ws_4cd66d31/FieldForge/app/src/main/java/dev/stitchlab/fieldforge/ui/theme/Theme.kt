package dev.stitchlab.fieldforge.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import dev.stitchlab.fieldforge.domain.model.ThemePreference

private val DarkColors = darkColorScheme(
    primary = ForgeAmber,
    onPrimary = ForgeInk,
    secondary = ForgeSteelLight,
    background = ForgeInk,
    surface = ForgeSteel,
    onBackground = Color(0xFFF2F4F7),
    onSurface = Color(0xFFF2F4F7),
    error = ForgeError,
)

private val LightColors = lightColorScheme(
    primary = ForgeAmberDark,
    onPrimary = Color.White,
    secondary = ForgeSteel,
    background = ForgeSand,
    surface = Color.White,
    onBackground = ForgeInk,
    onSurface = ForgeInk,
    error = ForgeError,
)

@Composable
fun FieldForgeTheme(
    preference: ThemePreference,
    content: @Composable () -> Unit,
) {
    val dark = when (preference) {
        ThemePreference.DARK -> true
        ThemePreference.LIGHT -> false
        ThemePreference.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = FieldForgeTypography,
        content = content,
    )
}
