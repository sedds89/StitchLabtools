package dev.stitchlab.fieldforge.domain.repository

import dev.stitchlab.fieldforge.domain.ForgeResult
import dev.stitchlab.fieldforge.domain.model.ThemePreference
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    fun observeTheme(): Flow<ThemePreference>
    suspend fun setTheme(preference: ThemePreference): ForgeResult<Unit>
}
