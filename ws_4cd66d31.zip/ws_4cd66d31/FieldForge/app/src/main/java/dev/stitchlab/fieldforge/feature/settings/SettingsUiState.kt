package dev.stitchlab.fieldforge.feature.settings

import dev.stitchlab.fieldforge.domain.model.ThemePreference

data class SettingsUiState(
    val theme: ThemePreference = ThemePreference.SYSTEM,
    val versionName: String = "1.0.0",
    val exportMessage: String? = null,
    val errorMessage: String? = null,
)
