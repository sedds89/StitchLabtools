package dev.stitchlab.fieldforge.domain

sealed class ForgeResult<out T> {
    data class Ok<T>(val value: T) : ForgeResult<T>()
    data class Err(val message: String, val cause: Throwable? = null) : ForgeResult<Nothing>()

    val isOk: Boolean get() = this is Ok
    fun getOrNull(): T? = (this as? Ok)?.value
}
