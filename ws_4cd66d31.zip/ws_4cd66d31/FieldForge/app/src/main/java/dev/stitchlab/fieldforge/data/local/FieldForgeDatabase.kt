package dev.stitchlab.fieldforge.data.local

import android.content.Context

class FieldForgeDatabase private constructor() {
    private val jobs = JobDao()
    private val notes = JobNoteDao()

    fun jobDao(): JobDao = jobs
    fun jobNoteDao(): JobNoteDao = notes

    companion object {
        @Volatile
        private var instance: FieldForgeDatabase? = null

        fun get(context: Context): FieldForgeDatabase {
            return instance ?: synchronized(this) {
                instance ?: FieldForgeDatabase().also { instance = it }
            }
        }
    }
}
