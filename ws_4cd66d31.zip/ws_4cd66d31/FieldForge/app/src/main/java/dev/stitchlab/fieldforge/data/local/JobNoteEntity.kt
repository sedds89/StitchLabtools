package dev.stitchlab.fieldforge.data.local

import dev.stitchlab.fieldforge.domain.model.JobNote

data class JobNoteEntity(
    val id: Long = 0L,
    val jobId: Long,
    val body: String,
    val createdAtEpochMs: Long,
) {
    fun toDomain(): JobNote = JobNote(
        id = id,
        jobId = jobId,
        body = body,
        createdAtEpochMs = createdAtEpochMs,
    )
}
