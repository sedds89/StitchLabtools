package dev.stitchlab.fieldforge

import android.app.Application
import dev.stitchlab.fieldforge.di.AppContainer

class FieldForgeApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
