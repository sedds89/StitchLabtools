package dev.stitchlab.fieldforge.ui.theme

import androidx.compose.ui.graphics.Color

val ForgeAmber = Color(0xFFE8A838)
val ForgeAmberDark = Color(0xFFC4841A)
val ForgeSteel = Color(0xFF1C2430)
val ForgeSteelLight = Color(0xFF2A3544)
val ForgeSand = Color(0xFFF4EFE6)
val ForgeInk = Color(0xFF12161C)
val ForgeError = Color(0xFFBA1A1A)
