package dev.stitchlab.fieldforge.domain.repository

import dev.stitchlab.fieldforge.domain.ForgeResult
import dev.stitchlab.fieldforge.domain.model.Job
import dev.stitchlab.fieldforge.domain.model.JobNote
import dev.stitchlab.fieldforge.domain.model.JobStatus
import kotlinx.coroutines.flow.Flow

interface JobRepository {
    fun observeJobs(): Flow<List<Job>>
    fun observeJob(id: Long): Flow<Job?>
    fun observeNotes(jobId: Long): Flow<List<JobNote>>
    suspend fun getJob(id: Long): ForgeResult<Job>
    suspend fun upsert(job: Job): ForgeResult<Long>
    suspend fun delete(id: Long): ForgeResult<Unit>
    suspend fun setStatus(id: Long, status: JobStatus): ForgeResult<Unit>
    suspend fun addNote(jobId: Long, body: String): ForgeResult<Unit>
}
