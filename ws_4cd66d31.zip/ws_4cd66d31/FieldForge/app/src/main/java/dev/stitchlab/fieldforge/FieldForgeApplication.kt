package dev.stitchlab.fieldforge

import android.app.Application
import dev.stitchlab.fieldforge.di.AppContainer

class FieldForgeApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
