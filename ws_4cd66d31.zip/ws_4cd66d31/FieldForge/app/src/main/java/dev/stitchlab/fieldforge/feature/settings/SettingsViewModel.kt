package dev.stitchlab.fieldforge.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dev.stitchlab.fieldforge.domain.ForgeResult
import dev.stitchlab.fieldforge.domain.model.ThemePreference
import dev.stitchlab.fieldforge.domain.repository.ExportRepository
import dev.stitchlab.fieldforge.domain.repository.JobRepository
import dev.stitchlab.fieldforge.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settings: SettingsRepository,
    private val jobs: JobRepository,
    private val exporter: ExportRepository,
    private val versionName: String,
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsUiState(versionName = versionName))
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            settings.observeTheme().collect { theme ->
                _state.update { it.copy(theme = theme) }
            }
        }
    }

    fun setTheme(theme: ThemePreference) {
        viewModelScope.launch {
            when (val result = settings.setTheme(theme)) {
                is ForgeResult.Ok -> _state.update { it.copy(errorMessage = null) }
                is ForgeResult.Err -> _state.update { it.copy(errorMessage = result.message) }
            }
        }
    }

    fun exportJobs() {
        viewModelScope.launch {
            val snapshot = jobs.snapshot()
            when (val result = exporter.exportJobsJson(snapshot)) {
                is ForgeResult.Ok -> _state.update {
                    it.copy(exportMessage = "Exported to ${result.value}", errorMessage = null)
                }
                is ForgeResult.Err -> _state.update { it.copy(errorMessage = result.message) }
            }
        }
    }

    companion object {
        fun factory(
            settings: SettingsRepository,
            jobs: JobRepository,
            exporter: ExportRepository,
            versionName: String,
        ): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return SettingsViewModel(settings, jobs, exporter, versionName) as T
                }
            }
    }
}
