package dev.stitchlab.fieldforge.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import dev.stitchlab.fieldforge.di.AppContainer
import dev.stitchlab.fieldforge.feature.dashboard.DashboardScreen
import dev.stitchlab.fieldforge.feature.dashboard.DashboardViewModel
import dev.stitchlab.fieldforge.feature.jobs.JobDetailScreen
import dev.stitchlab.fieldforge.feature.jobs.JobDetailViewModel
import dev.stitchlab.fieldforge.feature.jobs.JobEditScreen
import dev.stitchlab.fieldforge.feature.jobs.JobEditViewModel
import dev.stitchlab.fieldforge.feature.jobs.JobsScreen
import dev.stitchlab.fieldforge.feature.jobs.JobsViewModel
import dev.stitchlab.fieldforge.feature.settings.SettingsScreen
import dev.stitchlab.fieldforge.feature.settings.SettingsViewModel

@Composable
fun FieldForgeNav(container: AppContainer) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route.orEmpty()
    val showBar = route in setOf("dashboard", "jobs", "settings")

    Scaffold(
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    NavigationBarItem(
                        selected = route == "dashboard",
                        onClick = { nav.navigate("dashboard") { launchSingleTop = true } },
                        icon = { Icon(Icons.Filled.Home, contentDescription = "Dashboard") },
                        label = { Text("Dashboard") },
                    )
                    NavigationBarItem(
                        selected = route == "jobs",
                        onClick = { nav.navigate("jobs") { launchSingleTop = true } },
                        icon = { Icon(Icons.Filled.List, contentDescription = "Jobs") },
                        label = { Text("Jobs") },
                    )
                    NavigationBarItem(
                        selected = route == "settings",
                        onClick = { nav.navigate("settings") { launchSingleTop = true } },
                        icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "dashboard",
            modifier = Modifier.padding(padding),
        ) {
            composable("dashboard") {
                val vm: DashboardViewModel = viewModel(factory = factory { DashboardViewModel(container.jobs) })
                DashboardScreen(
                    viewModel = vm,
                    onOpenJob = { id -> nav.navigate("job/$id") },
                    onCreateJob = { nav.navigate("job/edit/0") },
                )
            }
            composable("jobs") {
                val vm: JobsViewModel = viewModel(factory = factory { JobsViewModel(container.jobs) })
                JobsScreen(
                    viewModel = vm,
                    onOpenJob = { id -> nav.navigate("job/$id") },
                    onCreateJob = { nav.navigate("job/edit/0") },
                )
            }
            composable(
                route = "job/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: 0L
                val vm: JobDetailViewModel = viewModel(
                    factory = factory { JobDetailViewModel(container.jobs, id) },
                )
                JobDetailScreen(
                    viewModel = vm,
                    onBack = { nav.popBackStack() },
                    onEdit = { jobId -> nav.navigate("job/edit/$jobId") },
                    onDeleted = { nav.popBackStack() },
                )
            }
            composable(
                route = "job/edit/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: 0L
                val vm: JobEditViewModel = viewModel(
                    factory = factory { JobEditViewModel(container.jobs, id) },
                )
                JobEditScreen(
                    viewModel = vm,
                    onBack = { nav.popBackStack() },
                    onSaved = { savedId ->
                        nav.popBackStack()
                        nav.navigate("job/$savedId")
                    },
                )
            }
            composable("settings") {
                val vm: SettingsViewModel = viewModel(
                    factory = factory { SettingsViewModel(container.settings, container.export) },
                )
                SettingsScreen(viewModel = vm)
            }
        }
    }
}

private inline fun <reified VM : ViewModel> factory(crossinline create: () -> VM): ViewModelProvider.Factory {
    return object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = create() as T
    }
}
