package dev.stitchlab.fieldforge.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

class JobDao {
    private val jobs = MutableStateFlow<List<JobEntity>>(emptyList())
    private var nextId = 1L

    fun observeAll(): Flow<List<JobEntity>> = jobs.map { list ->
        list.sortedByDescending { it.updatedAtEpochMs }
    }

    fun observeById(id: Long): Flow<JobEntity?> = jobs.map { list ->
        list.firstOrNull { it.id == id }
    }

    suspend fun getById(id: Long): JobEntity? = jobs.value.firstOrNull { it.id == id }

    /** Snapshot used by ExportForge JSON export. */
    fun snapshotJobs(): List<JobEntity> = getAll()

    suspend fun getAll(): List<JobEntity> = jobs.value.sortedByDescending { it.updatedAtEpochMs }

    suspend fun insert(entity: JobEntity): Long {
        val id = if (entity.id == 0L) nextId++ else entity.id
        val stored = entity.copy(id = id)
        jobs.update { current ->
            current.filterNot { it.id == id } + stored
        }
        if (id >= nextId) nextId = id + 1
        return id
    }

    suspend fun update(entity: JobEntity) {
        jobs.update { current ->
            current.map { if (it.id == entity.id) entity else it }
        }
    }

    suspend fun deleteById(id: Long) {
        jobs.update { current -> current.filterNot { it.id == id } }
    }

    suspend fun updateStatus(id: Long, status: String, updatedAt: Long) {
        jobs.update { current ->
            current.map {
                if (it.id == id) it.copy(status = status, updatedAtEpochMs = updatedAt) else it
            }
        }
    }
}
