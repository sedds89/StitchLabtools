package dev.stitchlab.fieldforge.domain.model

enum class ThemePreference { SYSTEM, LIGHT, DARK }
