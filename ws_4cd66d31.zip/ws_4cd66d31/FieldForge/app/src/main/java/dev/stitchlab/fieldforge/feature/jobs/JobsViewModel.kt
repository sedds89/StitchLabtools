package dev.stitchlab.fieldforge.feature.jobs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dev.stitchlab.fieldforge.domain.model.JobFilter
import dev.stitchlab.fieldforge.domain.repository.JobRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class JobsViewModel(
    jobRepository: JobRepository,
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val filter = MutableStateFlow(JobFilter.ALL)

    val uiState: StateFlow<JobsUiState> = combine(
        jobRepository.observeJobs(),
        query,
        filter,
    ) { jobs, q, f ->
        val byFilter = when (f) {
            JobFilter.ALL -> jobs
            JobFilter.OPEN -> jobs.filter { it.status == dev.stitchlab.fieldforge.domain.model.JobStatus.OPEN }
            JobFilter.COMPLETED -> jobs.filter { it.status == dev.stitchlab.fieldforge.domain.model.JobStatus.COMPLETED }
        }
        val needle = q.trim().lowercase()
        val filtered = if (needle.isEmpty()) {
            byFilter
        } else {
            byFilter.filter { job ->
                listOf(
                    job.customerName,
                    job.phone,
                    job.address,
                    job.description,
                    job.notes,
                ).any { it.lowercase().contains(needle) }
            }
        }
        JobsUiState(
            jobs = filtered,
            query = q,
            filter = f,
            isLoading = false,
            errorMessage = null,
        )
    }.catch { e ->
        emit(JobsUiState(isLoading = false, errorMessage = e.message ?: "Unable to load jobs"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = JobsUiState(),
    )

    fun onQueryChange(value: String) {
        query.value = value
    }

    fun onFilterChange(value: JobFilter) {
        filter.value = value
    }

    class Factory(private val jobRepository: JobRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return JobsViewModel(jobRepository) as T
        }
    }
}
