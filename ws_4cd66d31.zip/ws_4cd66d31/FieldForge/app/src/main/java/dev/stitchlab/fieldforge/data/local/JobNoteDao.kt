package dev.stitchlab.fieldforge.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

class JobNoteDao {
    private val notes = MutableStateFlow<List<JobNoteEntity>>(emptyList())
    private var nextId = 1L

    fun observeForJob(jobId: Long): Flow<List<JobNoteEntity>> = notes.map { list ->
        list.filter { it.jobId == jobId }.sortedByDescending { it.createdAtEpochMs }
    }

    suspend fun insert(entity: JobNoteEntity): Long {
        val id = if (entity.id == 0L) nextId++ else entity.id
        val stored = entity.copy(id = id)
        notes.update { current -> current + stored }
        return id
    }

    suspend fun deleteForJob(jobId: Long) {
        notes.update { current -> current.filterNot { it.jobId == jobId } }
    }
}
