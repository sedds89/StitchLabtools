package dev.stitchlab.fieldforge.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import dev.stitchlab.fieldforge.domain.repository.JobRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class DashboardViewModel(
    jobRepository: JobRepository,
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = combine(
        jobRepository.observeOpenJobs(),
        jobRepository.observeCompletedJobs(),
        jobRepository.observeTodaysJobs(),
    ) { open, completed, today ->
        DashboardUiState(
            openCount = open.size,
            completedCount = completed.size,
            todaysJobs = today,
            isLoading = false,
            errorMessage = null,
        )
    }.catch { e ->
        emit(DashboardUiState(isLoading = false, errorMessage = e.message ?: "Unable to load dashboard"))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState(),
    )

    class Factory(private val jobRepository: JobRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(jobRepository) as T
        }
    }
}
