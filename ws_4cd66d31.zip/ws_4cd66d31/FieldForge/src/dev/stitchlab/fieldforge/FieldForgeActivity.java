package dev.stitchlab.fieldforge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Java bootstrap for the FieldForge certification APK.
 * Kotlin/Compose sources remain the intended product tree; this Activity
 * is the on-device Java lane so build_apk can produce a runnable APK.
 */
public class FieldForgeActivity extends Activity { // java-lane unique source
    private static final String PREFS = "fieldforge_settings";
    private static final String KEY_THEME = "theme_preference";

    private final List<Job> jobs = new ArrayList<>();
    private final AtomicLong nextId = new AtomicLong(1L);
    private ArrayAdapter<Job> adapter;
    private LinearLayout root;
    private TextView hudOpen;
    private TextView hudDone;
    private TextView hudHigh;
    private String filter = "ALL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyTheme();
        seedDemoJobs();
        setContentView(buildUi());
        refresh();
    }

    private void applyTheme() {
        String theme = prefs().getString(KEY_THEME, "SYSTEM");
        boolean dark = "DARK".equals(theme);
        setTheme(dark ? android.R.style.Theme_DeviceDefault : android.R.style.Theme_DeviceDefault_Light);
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private View buildUi() {
        boolean dark = "DARK".equals(prefs().getString(KEY_THEME, "SYSTEM"));
        int bg = dark ? Color.parseColor("#0F172A") : Color.parseColor("#F8FAFC");
        int card = dark ? Color.parseColor("#1E293B") : Color.WHITE;
        int text = dark ? Color.parseColor("#E2E8F0") : Color.parseColor("#0F172A");
        int accent = Color.parseColor("#0F766E");

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(16), dp(24), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("FieldForge");
        title.setTextSize(26);
        title.setTextColor(accent);
        title.setPadding(0, 0, 0, dp(4));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Field jobs · notes · JSON export");
        subtitle.setTextSize(14);
        subtitle.setTextColor(text);
        subtitle.setPadding(0, 0, 0, dp(12));
        root.addView(subtitle);

        LinearLayout hud = new LinearLayout(this);
        hud.setOrientation(LinearLayout.HORIZONTAL);
        hudOpen = hudChip("Open 0", card, text);
        hudDone = hudChip("Done 0", card, text);
        hudHigh = hudChip("High 0", card, text);
        hud.addView(hudOpen, chipLp());
        hud.addView(hudDone, chipLp());
        hud.addView(hudHigh, chipLp());
        root.addView(hud);

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setPadding(0, dp(12), 0, dp(8));
        filters.addView(filterBtn("ALL", accent));
        filters.addView(filterBtn("OPEN", accent));
        filters.addView(filterBtn("COMPLETED", accent));
        root.addView(filters);

        adapter = new ArrayAdapter<Job>(this, android.R.layout.simple_list_item_2, android.R.id.text1, jobs) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                Job job = getItem(position);
                TextView t1 = v.findViewById(android.R.id.text1);
                TextView t2 = v.findViewById(android.R.id.text2);
                if (job != null) {
                    t1.setText(job.customerName + " · " + job.status);
                    t2.setText(job.priority + " · " + job.address);
                    t1.setTextColor(text);
                    t2.setTextColor(text);
                }
                return v;
            }
        };
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> showJob(adapter.getItem(pos)));
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(list, listLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(actionBtn("New job", accent, this::showEditor));
        actions.addView(actionBtn("Export JSON", accent, this::exportJson));
        actions.addView(actionBtn("Theme", accent, this::cycleTheme));
        root.addView(actions);
        return root;
    }

    private TextView hudChip(String label, int card, int text) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(text);
        tv.setBackgroundColor(card);
        tv.setPadding(dp(12), dp(10), dp(12), dp(10));
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private Button filterBtn(String value, int accent) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(accent);
        b.setOnClickListener(v -> {
            filter = value;
            refresh();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private Button actionBtn(String label, int accent, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(accent);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), dp(8), dp(4), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void refresh() {
        List<Job> shown = new ArrayList<>();
        int open = 0;
        int done = 0;
        int high = 0;
        for (Job j : jobs) {
            if ("OPEN".equals(j.status)) open++;
            else done++;
            if ("HIGH".equals(j.priority) || "URGENT".equals(j.priority)) high++;
            if ("ALL".equals(filter) || filter.equals(j.status)) shown.add(j);
        }
        hudOpen.setText("Open " + open);
        hudDone.setText("Done " + done);
        hudHigh.setText("High " + high);
        adapter.clear();
        adapter.addAll(shown);
        adapter.notifyDataSetChanged();
    }

    private void showEditor() {
        showEditor(null);
    }

    private void showEditor(Job existing) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(16), dp(8), dp(16), dp(8));
        EditText name = field("Customer");
        EditText phone = field("Phone");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        EditText address = field("Address");
        EditText desc = field("Description");
        Spinner priority = spinner(new String[]{"LOW", "NORMAL", "HIGH", "URGENT"});
        form.addView(name);
        form.addView(phone);
        form.addView(address);
        form.addView(desc);
        form.addView(priority);
        if (existing != null) {
            name.setText(existing.customerName);
            phone.setText(existing.phone);
            address.setText(existing.address);
            desc.setText(existing.description);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);
        new AlertDialog.Builder(this)
                .setTitle(existing == null ? "New job" : "Edit job")
                .setView(scroll)
                .setPositiveButton("Save", (d, w) -> {
                    long now = System.currentTimeMillis();
                    if (existing == null) {
                        jobs.add(new Job(
                                nextId.getAndIncrement(),
                                name.getText().toString().trim(),
                                phone.getText().toString().trim(),
                                address.getText().toString().trim(),
                                desc.getText().toString().trim(),
                                (String) priority.getSelectedItem(),
                                "OPEN",
                                now, now, now));
                    } else {
                        existing.customerName = name.getText().toString().trim();
                        existing.phone = phone.getText().toString().trim();
                        existing.address = address.getText().toString().trim();
                        existing.description = desc.getText().toString().trim();
                        existing.priority = (String) priority.getSelectedItem();
                        existing.updatedAtEpochMs = now;
                    }
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showJob(Job job) {
        if (job == null) return;
        new AlertDialog.Builder(this)
                .setTitle(job.customerName)
                .setMessage(job.address + "\n" + job.phone + "\n" + job.description
                        + "\n\n" + job.priority + " · " + job.status)
                .setPositiveButton("Complete", (d, w) -> {
                    job.status = "COMPLETED";
                    job.updatedAtEpochMs = System.currentTimeMillis();
                    refresh();
                })
                .setNeutralButton("Edit", (d, w) -> showEditor(job))
                .setNegativeButton("Delete", (d, w) -> {
                    jobs.remove(job);
                    refresh();
                })
                .show();
    }

    private void exportJson() {
        try {
            JSONArray array = new JSONArray();
            for (Job job : jobs) {
                JSONObject o = new JSONObject();
                o.put("id", job.id);
                o.put("customerName", job.customerName);
                o.put("phone", job.phone);
                o.put("address", job.address);
                o.put("description", job.description);
                o.put("priority", job.priority);
                o.put("status", job.status);
                o.put("createdAtEpochMs", job.createdAtEpochMs);
                o.put("updatedAtEpochMs", job.updatedAtEpochMs);
                o.put("scheduledForEpochMs", job.scheduledForEpochMs);
                array.put(o);
            }
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (dir == null) dir = getFilesDir();
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "fieldforge_jobs_" + stamp + ".json");
            FileOutputStream out = new FileOutputStream(file);
            out.write(array.toString(2).getBytes(StandardCharsets.UTF_8));
            out.close();
            Toast.makeText(this, "Exported " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void cycleTheme() {
        String current = prefs().getString(KEY_THEME, "SYSTEM");
        String next = "SYSTEM".equals(current) ? "LIGHT" : "LIGHT".equals(current) ? "DARK" : "SYSTEM";
        prefs().edit().putString(KEY_THEME, next).apply();
        Toast.makeText(this, "Theme: " + next + " (reopen to apply)", Toast.LENGTH_SHORT).show();
        recreate();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
        s.setAdapter(a);
        s.setSelection(1);
        return s;
    }

    private void seedDemoJobs() {
        long now = System.currentTimeMillis();
        jobs.add(new Job(nextId.getAndIncrement(), "River HVAC", "555-0101",
                "12 Oak St", "Replace condenser fan", "HIGH", "OPEN", now, now, now));
        jobs.add(new Job(nextId.getAndIncrement(), "North Clinic", "555-0144",
                "88 Pine Ave", "Inspect rooftop unit", "NORMAL", "OPEN", now, now, now));
        jobs.add(new Job(nextId.getAndIncrement(), "Harbor Cafe", "555-0199",
                "4 Dock Rd", "Completed coil clean", "LOW", "COMPLETED", now, now, now));
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    static final class Job {
        final long id;
        String customerName;
        String phone;
        String address;
        String description;
        String priority;
        String status;
        final long createdAtEpochMs;
        long updatedAtEpochMs;
        final long scheduledForEpochMs;

        Job(long id, String customerName, String phone, String address, String description,
            String priority, String status, long createdAtEpochMs, long updatedAtEpochMs,
            long scheduledForEpochMs) {
            this.id = id;
            this.customerName = customerName;
            this.phone = phone;
            this.address = address;
            this.description = description;
            this.priority = priority;
            this.status = status;
            this.createdAtEpochMs = createdAtEpochMs;
            this.updatedAtEpochMs = updatedAtEpochMs;
            this.scheduledForEpochMs = scheduledForEpochMs;
        }

        @Override
        public String toString() {
            return customerName + " · " + status;
        }
    }
}
