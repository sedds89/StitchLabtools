# Thread task memory
thread: th_3062ffeb-0

## Goal
- FRANKENSTEIN FIRST LoRA BUILD + OFFLINE CERTIFICATION

You are operating inside the Frankenstein development environment.

Your job is NOT merely to build an APK.

Your job is to perform the first controlled certification that Frankenstein can:

1. Use Grok as the frontier teacher.
2. Build a complete Android APK from one product prompt.
3. Capture useful development/training material from the suc

## Checkpoint (auto @ max turns)
GOAL: FRANKENSTEIN FIRST LoRA BUILD + OFFLINE CERTIFICATION You are operating inside the Frankenstein development environment. Your job is NOT merely to build an APK. Your job is to perform the first controlled certification that Frankenstein can: 1. Use Grok as the frontier teacher. 2. Build a complete Android APK from one product prompt. 3. Capture useful development/training material from the suc
LAST_BUILD: FAIL · {"ok":false,"tool":"build_apk","failedStep":"prepare","exitCode":1,"stdoutB64":"(decoded → stdout; 146 chars)","hint":"build_apk is only a convenience wrapper. Diagnose by running the manual steps via
LAST_BUILD_ERRORS (fix ONLY these — do not re-discover):
{"ok":false,"tool":"build_apk","failedStep":"prepare","exitCode":1,"stdoutB64":"(decoded → stdout; 146 chars)","hint":"build_apk is only a convenience wrapper. Diagnose by running the manual steps via run_runtime_tool (a
build_fail_count=2 — do not re-run identical build_apk
written: FieldForge/local.properties, frankenstein_lora_cert/phase1_baseline.json, frankenstein_lora_cert/failures/F01_gradle_jdk_fork.json, FieldForge/app/src/main/java/dev/stitchlab/fieldforge/FieldForgeApplication.kt, FieldForge/app/AndroidManifest.xml, FieldForge/app/res/values/strings.xml, FieldForge/app/res/values/themes.xml, FieldForge/app/res/drawable/ic_launcher_fieldforge.xml, frankenstein_lora_cert/failures/F02_build_apk_prepare.json, frankenstein_lora_cert/FIRST_LORA_CERTIFICATION.md, frankenstein_lora_cert/results.json, frankenstein_lora_cert/phase4_training_data.json, frankenstein_lora_cert/phase5_train.json, frankenstein_lora_cert/phase6_isolation.json, frankenstein_lora_cert/phase7_generalization.json, frankenstein_lora_cert/phase8_offline_warranty.json, frankenstein_lora_cert/phase9_ab.json, frankenstein_lora_cert/phase10_regression.json, frankenstein_lora_cert/failures/F03_aapt2_android_jar.json, FieldForge/app/src/main/java/dev/stitchlab/fieldforge/domain/model/ThemePreference.kt
rules: patch one error then build same cwd; no new sm_* clones; no full rewrites; never hand-write R.java; match class names across files.

## Open items
- Fix LAST_BUILD_ERRORS with patch_file, then build_apk same cwd once
- Do not re-scaffold or create sm_v2/sm_a16 clones
- Do not re-run identical tools (LOOP_BLOCKED)

## Last assistant (snip)
Kotlinc is past aapt2; `ExportForge` calls `jobDao.getAll()` which the in-memory DAO does not expose. Adding that snapshot method, then rebuilding.
