# Workspace rules (Frankenstein)

Edit in Space → Rules. Workspace rules are OFF by default until you enable them.

## Code quality
- Match existing patterns; minimal diffs (patch over rewrite).

## Art & sprites (prevents white-box low-quality assets)
- generate_image: ALWAYS style=sprite OR transparent=true for characters, items, tiles, icons.
- Never ship sprites with white/card backgrounds — require transparent PNG knockout.
- Save under assets/sprites/ or assets/tiles/; verify alpha before wiring into code.

## Build verify
- When user wants runnable APK: build_apk → install_apk → launch_app.

## Preferences
- 
