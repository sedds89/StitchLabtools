# Project map
Fill after first explore. Agents: read this before re-scanning the tree.

## Layout
- 

## Entry points
- 

## Build / run
- 

## Seen paths (auto)
- /codebase_index.js, /memory.md, /project_map.md, /rules.md, /semantic_index.js, /th_3062ffeb-0.md, /records.js, /FLAGSHIP_ON_DEVICE_BUILD.md, .aide/codebase_index.js, .aide/memory.md, .aide/project_map.md, .aide/rules.md, .aide/semantic_index.js, .aide/threads/th_3062ffeb-0.md, odebase_index.js, emo

## Seen paths (auto)
- /ExportForge.kt, FieldForge/app/src/main/java/dev/stitchlab/fieldforge/data/local/JobEntity.kt, FieldForge/app/src/main/java/dev/stitchlab/fieldforge/data/local/JobNoteEntity.kt, FieldForge/app/src/main/java/dev/stitchlab/fieldforge/data/local/JobDao.kt, FieldForge/app/src/main/java/dev/stitchlab/fi
